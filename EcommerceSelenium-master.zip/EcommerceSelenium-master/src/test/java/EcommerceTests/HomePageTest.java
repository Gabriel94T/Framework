package EcommerceTests;

public class HomePageTest 
{
	/*Test 1 
	 * Create the test on home page that once you click in the footer on Youtube logo 
	 * customer is redirected to youtube channel
	 * *-**************************************************
	 * 	/*Test 2 
	 * Create the test on home page that once you click in the footer on Facebook logo 
	 * customer is redirected to Facebook channel
	 * *-**************************************************
	 * 
	 * 	/*Test 3 
	 * Create the test on home page that once you click in the footer on Twitter logo 
	 * customer is redirected to Twitter channel
	 * *-**************************************************
	 * 
	 * 	/*Test 4 
	 * Create the test on home page that once you click in the footer on Google(G+) logo 
	 * customer is redirected to youtube channel
	 * *-**************************************************
	 * 
	 * 	/*Test 5 
	 * Create the test on home page that once you click in the footer on the Categories > Woman 
	 * customer is redirected to the Woman page (containing all the products for woman -> make sure you create relevant class for that page
	 * *-**************************************************
	 * 	/*Test 6 
	 * Create the test on home page that once you click in the footer on the Information > Sitemap 
	 * customer is redirected to the Sitemap page  make sure you create relevant class for that page
	 * *-**************************************************
	 * 	/*Test 7 
	 * Create the test on home page that once you click in the footer on the Information >  About us 
	 * customer is redirected to the About page   -> make sure you create relevant class for that page
	 * *-**************************************************
	 * 	/*Test 8 
	 * Create the test on home page that once you click in the footer on the My account > My order 
	 * customer is redirected to the My order page -> make sure you create relevant class for that page (only when the customer is logged in first)
	 * *-**************************************************
	 *  	/*Test 9 
	 * Create the test on home page that once you click in the footer on the My account > My order 
	 * customer is redirected to the Login -> Use existing Loging page (class to move there) - > customer is not logged in
	 * *-**************************************************
	 * 
	 *  *  	/*Test 10
	 * Create the test on home page Top page -> menu bar
	 * HoverOver Woman section -> verify that menu will opens with relevant categories
	 * *-**************************************************
	 *  *  *  	/*Test 11
	 * Create the test on home page Top page -> menu bar
	 * HoverOver Dress section -> verify that menu will opens with relevant categories
	 * *-**************************************************
	 *   	/*Test 12
	 * Create the test on home page Top page -> Main Logo 
	 * Click on the logo on top of the page make sure that customer stays on the same page
	 * *-**************************************************.
	 * *   	/*Test 13
	 * Create the test on home page Top page -> Cart 
	 * Click on the Cart on top right  of the page -> verify SHOPPING-CART SUMMARY occurs on the bottom of the page
	 * *-**************************************************
	 * /*Test 14
	 * Create the test on home page Top page -> Cart 
	 * Click on the Cart on top right  of the page -> verify SHOPPING-CART SUMMARY occurs on the bottom of the page
	 * click on the Logo on top page and verify that SHOPPING-CART SUMMARY no longer exist on the page - > customer stays on the same page
	 * *-**************************************************
	 * /*Test 14
	 * Create the test on home page Top page -> Contact Us (Beside Sign in button -> top right) 
	 * Click on the Contact Us on top right  of the page -> Customer will be redirected to Contact Us page (make sure you are using new created Contact Us page/class))
	 *  
	 * 
	 * 
	 * */
}
